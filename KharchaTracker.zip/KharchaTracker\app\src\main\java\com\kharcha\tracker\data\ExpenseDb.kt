package com.kharcha.tracker.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.time.YearMonth

data class Expense(
    val id: Long = 0,
    val amount: Double,
    val category: String,
    val note: String,
    val date: String, // ISO format: yyyy-MM-dd
)

/**
 * Simple offline storage for expenses using SQLite (no internet permission needed).
 */
class ExpenseDb(context: Context) {

    private val helper = object : SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {
        override fun onCreate(db: SQLiteDatabase) {
            db.execSQL(
                "CREATE TABLE $TABLE (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "amount REAL NOT NULL, " +
                    "category TEXT NOT NULL, " +
                    "note TEXT NOT NULL DEFAULT '', " +
                    "date TEXT NOT NULL)"
            )
            db.execSQL("CREATE INDEX idx_expense_date ON $TABLE(date)")
        }

        override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
            // Future migrations go here.
        }
    }

    private val db: SQLiteDatabase by lazy { helper.writableDatabase }

    fun insert(expense: Expense): Long {
        return db.insert(TABLE, null, expense.toValues())
    }

    fun update(expense: Expense) {
        db.update(TABLE, expense.toValues(), "id = ?", arrayOf(expense.id.toString()))
    }

    fun delete(id: Long) {
        db.delete(TABLE, "id = ?", arrayOf(id.toString()))
    }

    fun forDate(date: String): List<Expense> = query("date = ?", arrayOf(date))

    fun forMonth(month: YearMonth): List<Expense> =
        query("date >= ? AND date <= ?", arrayOf(month.atDay(1).toString(), month.atEndOfMonth().toString()))

    fun all(): List<Expense> = query("1 = 1", emptyArray())

    private fun query(where: String, args: Array<String>): List<Expense> =
        db.query(TABLE, null, where, args, null, null, "date DESC, id DESC").use { cursor ->
            val result = mutableListOf<Expense>()
            while (cursor.moveToNext()) {
                result += Expense(
                    id = cursor.getLong(0),
                    amount = cursor.getDouble(1),
                    category = cursor.getString(2),
                    note = cursor.getString(3) ?: "",
                    date = cursor.getString(4),
                )
            }
            result
        }

    private fun Expense.toValues() = ContentValues().apply {
        put("amount", amount)
        put("category", category)
        put("note", note)
        put("date", date)
    }

    private companion object {
        const val TABLE = "expenses"
        const val DB_NAME = "expenses.db"
        const val DB_VERSION = 1
    }
}
