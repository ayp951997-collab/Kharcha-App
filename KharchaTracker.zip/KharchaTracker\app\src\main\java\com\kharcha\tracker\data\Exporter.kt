package com.kharcha.tracker.data

import android.content.Context
import android.net.Uri
import androidx.core.content.FileProvider
import java.io.File
import java.time.YearMonth
import java.time.format.DateTimeFormatter

/**
 * Month ke saare expenses ek CSV file me export karke shareable Uri return karta hai.
 * null = is month me koi expense nahi hai.
 */
fun exportMonthCsv(context: Context, db: ExpenseDb, month: YearMonth): Uri? {
    val expenses = db.forMonth(month)
    if (expenses.isEmpty()) return null

    val dir = File(context.cacheDir, "exports").apply { mkdirs() }
    val fileName = "kharcha-" + month.format(DateTimeFormatter.ofPattern("yyyy-MM")) + ".csv"
    val file = File(dir, fileName)

    file.writeText(
        buildString {
            append("\uFEFF") // Excel me Hindi/unicode text sahi dikhe
            appendLine("Date,Category,Note,Amount")
            expenses.forEach { expense ->
                appendLine(
                    listOf(
                        expense.date,
                        csvEscape(expense.category),
                        csvEscape(expense.note),
                        expense.amount.toString(),
                    ).joinToString(",")
                )
            }
        }
    )

    return FileProvider.getUriForFile(context, context.packageName + ".fileprovider", file)
}

private fun csvEscape(value: String): String =
    if (value.contains(',') || value.contains('"') || value.contains('\n')) {
        "\"" + value.replace("\"", "\"\"") + "\""
    } else {
        value
    }
