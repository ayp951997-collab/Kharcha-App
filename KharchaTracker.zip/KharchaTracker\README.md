# Kharcha Tracker 📱💰

Ek **fully free** (no ads, no login, offline) Android app for daily & monthly expense tracking.

## Features
- ➕ Expense add karo: amount, category, note, date
- 📅 **Daily tab**: aaj (ya kisi bhi date) ka kharcha, date navigation + date picker
- 📊 **Monthly tab**: mahine ka total, category-wise breakdown bars, date-wise list
- ✏️ Kisi bhi entry par tap karke edit karo, 🗑️ delete button se delete
- 💰 **Monthly budget** set karo (⚙️ icon) — limit cross hone par red warning + kitna bacha hai
- 📤 **CSV export** (📤 icon, Monthly tab) — Excel/Google Sheets me kholo, WhatsApp/Gmail pe share karo
- 💾 Data phone me hi save hota hai (SQLite) — internet ki zaroorat nahi
- 🌙 Dark mode support (system ke saath)
- 🇮🇳 ₹ Indian currency format

## APK kaise banaye (Android Studio se)
1. [Android Studio](https://developer.android.com/studio) download & install karo (latest version).
2. Android Studio me **File → Open** karo aur is `KharchaTracker` folder ko select karo.
3. Gradle sync hone do (pehli baar internet chahiye dependencies ke liye).
4. App turant chalane ke liye: emulator ya USB-connected phone select karke **Run ▶** dabao.
5. **APK file** banane ke liye:
   - Menu: **Build → Build App Bundle(s) / APK(s) → Build APK(s)**
   - APK yahan milegi: `app/build/outputs/apk/debug/app-debug.apk`
   - Is APK ko phone me copy karke install karo (unknown sources allow karna pad sakta hai).

## Play Store ke liye release APK
- **Build → Generate Signed App Bundle / APK** se apni keystore bana kar signed release APK/bundle banao.

## Project structure
```
app/src/main/java/com/kharcha/tracker/
├── MainActivity.kt          # App entry point
├── data/ExpenseDb.kt        # SQLite storage (add/edit/delete/query)
└── ui/
    ├── ExpenseTrackerApp.kt # Main screen: Daily/Monthly tabs, lists, totals
    ├── AddExpenseDialog.kt  # Add/Edit dialog with category dropdown + date picker
    └── Theme.kt             # Material 3 colors, dark mode
```

## Tech
- Kotlin + Jetpack Compose (Material 3)
- SQLiteOpenHelper (koi bhaari dependency nahi, fast build)
- minSdk 26 (Android 8+), targetSdk 35
