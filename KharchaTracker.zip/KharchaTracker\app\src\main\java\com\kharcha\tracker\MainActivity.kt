package com.kharcha.tracker

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.kharcha.tracker.data.ExpenseDb
import com.kharcha.tracker.ui.ExpenseTrackerApp
import com.kharcha.tracker.ui.KharchaTrackerTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = ExpenseDb(this)
        setContent {
            KharchaTrackerTheme {
                ExpenseTrackerApp(db)
            }
        }
    }
}
