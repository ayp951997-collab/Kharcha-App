package com.kharcha.tracker.ui

import android.content.Context
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp

private const val PREFS = "kharcha_prefs"
private const val KEY_BUDGET = "monthly_budget"

fun loadBudget(context: Context): Double? =
    context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .getString(KEY_BUDGET, null)?.toDoubleOrNull()

fun saveBudget(context: Context, budget: Double?) {
    context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().apply {
        if (budget == null) remove(KEY_BUDGET) else putString(KEY_BUDGET, budget.toString())
    }.apply()
}

@Composable
fun BudgetDialog(
    current: Double?,
    onSave: (Double?) -> Unit,
    onDismiss: () -> Unit,
) {
    var amountText by remember {
        mutableStateOf(
            current?.let { if (it % 1.0 == 0.0) it.toLong().toString() else it.toString() } ?: ""
        )
    }
    val amount = amountText.toDoubleOrNull()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Monthly Budget") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    "Mahine ki kharch limit set karo. Limit cross hone par app warn karegi.",
                    style = MaterialTheme.typography.bodySmall,
                )
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it.filter { ch -> ch.isDigit() || ch == '.' } },
                    label = { Text("Budget (₹)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        },
        confirmButton = {
            TextButton(
                enabled = amount != null && amount > 0.0,
                onClick = { onSave(amount) },
            ) { Text("Save") }
        },
        dismissButton = {
            Row {
                if (current != null) {
                    TextButton(onClick = { onSave(null) }) { Text("Remove") }
                }
                TextButton(onClick = onDismiss) { Text("Cancel") }
            }
        },
    )
}
