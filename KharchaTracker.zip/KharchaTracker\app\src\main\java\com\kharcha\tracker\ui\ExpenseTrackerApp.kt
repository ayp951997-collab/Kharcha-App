@file:OptIn(ExperimentalMaterial3Api::class)

package com.kharcha.tracker.ui

import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.kharcha.tracker.data.Expense
import com.kharcha.tracker.data.ExpenseDb
import com.kharcha.tracker.data.exportMonthCsv
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.NumberFormat
import java.time.Instant
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.util.Locale

private val moneyFormat = NumberFormat.getCurrencyInstance(Locale.forLanguageTag("en-IN"))
private val dayFormat = DateTimeFormatter.ofPattern("EEE, dd MMM yyyy", Locale.ENGLISH)
private val shortDayFormat = DateTimeFormatter.ofPattern("dd MMM", Locale.ENGLISH)
private val monthDayFormat = DateTimeFormatter.ofPattern("EEE, dd MMM", Locale.ENGLISH)
private val monthFormat = DateTimeFormatter.ofPattern("MMMM yyyy", Locale.ENGLISH)

@Composable
fun ExpenseTrackerApp(db: ExpenseDb) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var selectedDate by remember { mutableStateOf(LocalDate.now()) }
    var selectedMonth by remember { mutableStateOf(YearMonth.now()) }
    var refresh by remember { mutableIntStateOf(0) }
    var showAddDialog by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Expense?>(null) }
    var showBudgetDialog by remember { mutableStateOf(false) }
    val context = LocalContext.current
    var budget by remember { mutableStateOf(loadBudget(context)) }
    val scope = rememberCoroutineScope()

    val expenses by produceState<List<Expense>>(emptyList(), tab, selectedDate, selectedMonth, refresh) {
        value = withContext(Dispatchers.IO) {
            if (tab == 0) db.forDate(selectedDate.toString()) else db.forMonth(selectedMonth)
        }
    }

    fun save(amount: Double, category: String, note: String, date: String) {
        val current = editing
        scope.launch {
            withContext(Dispatchers.IO) {
                if (current == null) {
                    db.insert(Expense(amount = amount, category = category, note = note, date = date))
                } else {
                    db.update(current.copy(amount = amount, category = category, note = note, date = date))
                }
            }
            refresh++
            showAddDialog = false
            editing = null
        }
    }

    fun delete(expense: Expense) {
        scope.launch {
            withContext(Dispatchers.IO) { db.delete(expense.id) }
            refresh++
        }
    }

    fun exportMonth() {
        scope.launch {
            val uri = withContext(Dispatchers.IO) { exportMonthCsv(context, db, selectedMonth) }
            if (uri == null) {
                Toast.makeText(context, "Is month me koi kharcha nahi hai", Toast.LENGTH_SHORT).show()
                return@launch
            }
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "text/csv"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            runCatching {
                context.startActivity(Intent.createChooser(send, "Export Kharcha CSV"))
            }.onFailure {
                Toast.makeText(context, "CSV share karne wala app nahi mila", Toast.LENGTH_SHORT).show()
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Kharcha Tracker", fontWeight = FontWeight.SemiBold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                ),
                actions = {
                    IconButton(onClick = { showBudgetDialog = true }) {
                        Icon(Icons.Default.Settings, contentDescription = "Monthly budget")
                    }
                },
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { showAddDialog = true }) {
                Icon(Icons.Default.Add, contentDescription = "Add expense")
            }
        },
    ) { innerPadding ->
        Column(Modifier.padding(innerPadding).fillMaxSize()) {
            TabRow(selectedTabIndex = tab) {
                Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Daily") })
                Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Monthly") })
            }
            if (tab == 0) {
                DailyTab(
                    expenses = expenses,
                    date = selectedDate,
                    onDateChange = { selectedDate = it },
                    onEdit = { editing = it },
                    onDelete = ::delete,
                )
            } else {
                MonthlyTab(
                    expenses = expenses,
                    month = selectedMonth,
                    onMonthChange = { selectedMonth = it },
                    budget = budget,
                    onExport = ::exportMonth,
                    onEdit = { editing = it },
                    onDelete = ::delete,
                )
            }
        }
    }

    if (showAddDialog) {
        AddExpenseDialog(
            existing = null,
            onDismiss = { showAddDialog = false },
            onSave = ::save,
        )
    }
    editing?.let { expense ->
        AddExpenseDialog(
            existing = expense,
            onDismiss = { editing = null },
            onSave = ::save,
        )
    }

    if (showBudgetDialog) {
        BudgetDialog(
            current = budget,
            onSave = { newBudget ->
                budget = newBudget
                saveBudget(context, newBudget)
            },
            onDismiss = { showBudgetDialog = false },
        )
    }
}

@Composable
private fun DailyTab(
    expenses: List<Expense>,
    date: LocalDate,
    onDateChange: (LocalDate) -> Unit,
    onEdit: (Expense) -> Unit,
    onDelete: (Expense) -> Unit,
) {
    var showPicker by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = { onDateChange(date.minusDays(1)) }) {
                Icon(Icons.Default.KeyboardArrowLeft, contentDescription = "Previous day")
            }
            Text(
                text = date.format(dayFormat),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center,
                modifier = Modifier.weight(1f).clickable { showPicker = true }.padding(vertical = 8.dp),
            )
            IconButton(onClick = { onDateChange(date.plusDays(1)) }) {
                Icon(Icons.Default.KeyboardArrowRight, contentDescription = "Next day")
            }
        }
        TotalCard(
            title = "Spent today",
            total = expenses.sumOf { it.amount },
            count = expenses.size,
        )
        ExpenseList(
            expenses = expenses,
            showDate = false,
            emptyMessage = "No expenses on this day 🎉",
            onEdit = onEdit,
            onDelete = onDelete,
        )
    }

    if (showPicker) {
        val state = rememberDatePickerState(
            initialSelectedDateMillis = date.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli(),
        )
        DatePickerDialog(
            onDismissRequest = { showPicker = false },
            confirmButton = {
                TextButton(onClick = {
                    state.selectedDateMillis?.let { millis ->
                        onDateChange(Instant.ofEpochMilli(millis).atZone(ZoneOffset.UTC).toLocalDate())
                    }
                    showPicker = false
                }) { Text("OK") }
            },
            dismissButton = {
                TextButton(onClick = { showPicker = false }) { Text("Cancel") }
            },
        ) {
            DatePicker(state = state)
        }
    }
}

@Composable
private fun MonthlyTab(
    expenses: List<Expense>,
    month: YearMonth,
    onMonthChange: (YearMonth) -> Unit,
    budget: Double?,
    onExport: () -> Unit,
    onEdit: (Expense) -> Unit,
    onDelete: (Expense) -> Unit,
) {
    val total = expenses.sumOf { it.amount }
    val budgetValue = budget ?: 0.0
    val byCategory = remember(expenses) {
        expenses.groupBy { it.category }
            .map { (category, list) -> category to list.sumOf { it.amount } }
            .sortedByDescending { it.second }
    }
    val byDate = remember(expenses) {
        expenses.groupBy { it.date }.entries.sortedByDescending { it.key }
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = { onMonthChange(month.minusMonths(1)) }) {
                Icon(Icons.Default.KeyboardArrowLeft, contentDescription = "Previous month")
            }
            Text(
                text = month.format(monthFormat),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center,
                modifier = Modifier.weight(1f).padding(vertical = 8.dp),
            )
            IconButton(onClick = { onMonthChange(month.plusMonths(1)) }) {
                Icon(Icons.Default.KeyboardArrowRight, contentDescription = "Next month")
            }
            IconButton(onClick = onExport) {
                Icon(Icons.Default.Share, contentDescription = "Export month as CSV")
            }
        }

        if (expenses.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    "No expenses in this month",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                )
            }
            return
        }

        LazyColumn(Modifier.fillMaxSize()) {
            if (budgetValue > 0.0) {
                item { BudgetCard(total = total, budget = budgetValue) }
            }
            item {
                TotalCard(
                    title = "Spent this month",
                    total = total,
                    count = expenses.size,
                )
            }
            item {
                CategoryCard(byCategory)
            }
            byDate.forEach { (dateStr, list) ->
                item(key = "header_$dateStr") {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Text(
                            LocalDate.parse(dateStr).format(monthDayFormat),
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold,
                        )
                        Text(
                            moneyFormat.format(list.sumOf { it.amount }),
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
                items(list, key = { it.id }) { expense ->
                    ExpenseRow(
                        expense = expense,
                        showDate = false,
                        onClick = onEdit,
                        onDelete = onDelete,
                    )
                }
            }
        }
    }
}

@Composable
private fun TotalCard(title: String, total: Double, count: Int) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.labelMedium)
            Text(
                moneyFormat.format(total),
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
            )
            Text(
                "$count entries",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onPrimaryContainer,
            )
        }
    }
}

@Composable
private fun CategoryCard(byCategory: List<Pair<String, Double>>) {
    val total = byCategory.sumOf { it.second }
    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                "Category breakdown",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
            )
            byCategory.forEach { (category, amount) ->
                Column {
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Text(category, style = MaterialTheme.typography.bodyMedium)
                        Text(
                            moneyFormat.format(amount),
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Medium,
                        )
                    }
                    LinearProgressIndicator(
                        progress = { if (total > 0) (amount / total).toFloat() else 0f },
                        modifier = Modifier.fillMaxWidth().padding(top = 4.dp).height(6.dp),
                        trackColor = MaterialTheme.colorScheme.surface,
                    )
                }
            }
        }
    }
}

@Composable
private fun ExpenseList(
    expenses: List<Expense>,
    showDate: Boolean,
    emptyMessage: String,
    onEdit: (Expense) -> Unit,
    onDelete: (Expense) -> Unit,
) {
    if (expenses.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(
                emptyMessage,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
            )
        }
        return
    }
    LazyColumn(Modifier.fillMaxSize()) {
        items(expenses, key = { it.id }) { expense ->
            ExpenseRow(
                expense = expense,
                showDate = showDate,
                onClick = onEdit,
                onDelete = onDelete,
            )
        }
    }
}

@Composable
private fun ExpenseRow(
    expense: Expense,
    showDate: Boolean,
    onClick: (Expense) -> Unit,
    onDelete: (Expense) -> Unit,
) {
    ListItem(
        modifier = Modifier.clickable { onClick(expense) },
        leadingContent = {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(categoryColor(expense.category)),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    expense.category.take(1),
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                )
            }
        },
        headlineContent = {
            Text(
                if (expense.note.isBlank()) expense.category else expense.note,
                maxLines = 1,
            )
        },
        supportingContent = {
            Text(
                if (showDate) expense.category + " • " + LocalDate.parse(expense.date).format(shortDayFormat)
                else expense.category,
            )
        },
        trailingContent = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    moneyFormat.format(expense.amount),
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.primary,
                )
                IconButton(onClick = { onDelete(expense) }) {
                    Icon(
                        Icons.Default.Delete,
                        contentDescription = "Delete",
                        tint = MaterialTheme.colorScheme.error,
                    )
                }
            }
        },
    )
}

@Composable
private fun BudgetCard(total: Double, budget: Double) {
    val over = total > budget
    val remaining = budget - total
    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (over) MaterialTheme.colorScheme.errorContainer
            else MaterialTheme.colorScheme.tertiaryContainer,
        ),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("Monthly budget", style = MaterialTheme.typography.labelMedium)
                Text(
                    moneyFormat.format(budget),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                )
            }
            LinearProgressIndicator(
                progress = { (total / budget).coerceIn(0.0, 1.0).toFloat() },
                modifier = Modifier.fillMaxWidth().height(8.dp),
                color = if (over) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                trackColor = MaterialTheme.colorScheme.surface,
            )
            Text(
                if (over) {
                    "⚠️ Budget cross ho gaya! " + moneyFormat.format(-remaining) + " extra kharch ho gaye"
                } else {
                    "Budget me " + moneyFormat.format(remaining) + " bacha hai"
                },
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Medium,
            )
        }
    }
}

private fun categoryColor(category: String): Color {
    val palette = listOf(
        0xFFF97316, 0xFF10B981, 0xFF3B82F6, 0xFF8B5CF6,
        0xFFEF4444, 0xFF14B8A6, 0xFFF59E0B, 0xFF6366F1,
    )
    return Color(palette[Math.floorMod(category.hashCode(), palette.size)])
}
