# Add project specific ProGuard rules here.
# Keep defaults; Compose and Kotlinx do not need extra rules for this app.
